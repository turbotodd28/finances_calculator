Finances Calculator - Standalone Application

This package contains a standalone executable that can run on any Linux machine
without requiring Python or any dependencies to be installed.

INSTALLATION:
1. Extract this package to any location
2. Run: sudo ./install.sh
3. The application will be available system-wide with custom icon
4. A desktop shortcut will be created for easy access

USAGE:
- Run from terminal: finances_calculator
- Or find "Finances Calculator" in your applications menu
- Or double-click the desktop shortcut

FEATURES:
- Load CSV bank statements
- Calculate totals for selected transactions
- Highlight selected rows
- No dependencies required
- Custom money-themed icon
- Desktop shortcut for easy launching

The executable is completely self-contained and includes Python and all required libraries.
